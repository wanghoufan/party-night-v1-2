# Party Night V2 引擎 Phase 1 规划包 V1.1

本包分两部分：

- `00-V1.3冻结基线/`：题库与机制冻结输入，含 V1.3 全量文件、schema 笔误修正、runtimeRules SSOT 归一化和 SHA256 清单。
- `10-V2引擎Phase1-SDD/`：Constitution → SPEC → PLAN → TASKS + traceability + Planner自检 + Research Reviewer请求 + Human Gate。

**本包不包含业务代码修改。** 当前仍是 PLAN 阶段。
