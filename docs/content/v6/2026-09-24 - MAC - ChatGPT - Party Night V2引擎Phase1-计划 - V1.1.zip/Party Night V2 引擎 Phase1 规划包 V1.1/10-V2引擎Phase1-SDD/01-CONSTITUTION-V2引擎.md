# Party Night V2 Relationship Engine｜CONSTITUTION

> 文档状态：**Phase 1 Planner Draft — 禁止开发**  
> 拟议 Constitution 版本：**1.3.0**（Human Gate 批准后生效）  
> PRODUCT_PLAN：`PRODUCT_PLAN_V2.0`（草案）  
> 输入基线：Party Night V2 题库/机制 **V1.3 冻结版**  
> 变更等级：**Change C｜产品 / 架构变更**

## 0. 本轮治理边界

本轮处于 ORCA Phase 1（PLAN）。**Builder / Code Reviewer / QA 不得开始业务实现，不得改生产代码，不得 Release。** 正常治理链为：Planner → Research Reviewer → Planner 修订 → Readiness Gate → Human Gate。只有用户明确说“第二阶段，开发”后才能进入 DEVELOP。

## I. 继承且不得破坏的产品宪法

1. 保留四个底部 Tab：**首页 / 组局 / 游戏包 / 设置**；V2 Relationship Engine 是后台领域能力，不新增底部 Tab。
2. 保留现有 1–5 开放度 UI；V2 不另造第二套尺度体系。
3. 保留单设备、单桌、local-first、IndexedDB Session、PWA/offline、现有 AI Provider 与 BYOK 安全边界。
4. 保留 Party Game Engine 与 Game Pack 解耦；V2 是 Engine 能力扩展，不复制第二套 App / 第二套 Session / 第二套存储。
5. 同一 Session 切换玩法不得重新设置玩家、关系、氛围、开放度，也不得丢失 V2 Relationship State。
6. 不引入账号、支付、云数据库、多人实时房间、跨设备秘密投票、向量库或新的全局状态框架。

## II. V2 Relationship Engine 不可违反的硬规则

1. **SSOT**：运行时默认值与算法参数只读取 `10-卡片元数据.json.runtimeRules`；不得在 UI、selector、test fixture 中再维护一份手写常量作为第二事实源。
2. **Heat**：Session Heat 只有 `H1/H2/H3/H4`；**不存在全桌 H5**。
3. **Intensity**：玩家选择的 1–5 是允许内容的上限，不是当前 Heat，也不是抽卡概率。
4. **5档**：只对满足逐卡合法条件的具体 pair 开放；不能因时间、全桌投票或单向选择自动开放。
5. **MATCH**：只有 `SYSTEM_MUTUAL_CHECK` 中双方分别秘密选中彼此才创建；Crowd/Shared/Compatibility/Personal 均不得升级成 MATCH。
6. MATCH 是“当前愿意继续了解”，不是恋爱标签、排他关系、身体接触许可；同一玩家允许与不同对象形成 Session-level MATCH。
7. **Consent**：身体接触、靠近、移动到对方身边、持续对视、拍照/录像等具体动作必须当场再次同意；无共同动作交集就跳过，不自动替换。
8. **Skip**：永远合法、不罚酒、不扣分、不解释；跳过不得锁死其他人的 Heat 或 `SYSTEM_MUTUAL_CHECK`。
9. **Privacy**：单向秘密选择只在当前私密流程内短暂存在；完成匹配判断后立即删除，不写长期历史，不上传第三方分析。
10. **Signals 分离**：Shared / Compatibility / Crowd / Personal / Mutual 语义和权重分离；眼神、笑、靠近等行为事件不得推断为“喜欢”。
11. **Routing Score** 仅代表“下一轮安排优先级”，不得对用户展示成爱情概率、匹配率或兼容百分比。
12. `one-off-mutual` 只解锁当轮一次性动作/加赛，不创建持久 MATCH。

## III. 私密输入的唯一例外

既有产品原则是“手机是 Party 主持人，不要求日常逐人录入”。V2 仅允许两个最小例外：

- `SYSTEM_MUTUAL_CHECK`：单设备传手机、逐人私密选择；
- `private-mutual-only`：双方分别选择当次可接受动作/加赛。

除此之外，真心话、投票、默契等继续优先维持 Host 驱动或公开互动，不把全局体验改造成“每题每人低头点手机”。

私密流程必须满足：遮挡上一位答案 → 当前玩家确认身份 → 作答 → 明确提交 → 立即遮罩 → 传给下一位。刷新/崩溃时不得恢复已输入的单向秘密答案；未完成私密事件直接作废。

## IV. Relationship-aware 与 Neutral Pack

为了保护现有插件式 Game Pack 架构：

- V1.3 的 7 类主线题库属于 `relationship-aware`，可参与 Heat / Pair / Signal / MATCH / 5档路由。
- 扩圈卡使用独立规则：不进入 Pair Score / MATCH；Phase 1 默认**不推进 Relationship Heat，也不计入 `SYSTEM_MUTUAL_CHECK` 的有效卡间隔**。
- AI 即兴、转瓶子、自定义包及未声明 V2 元数据能力的玩法默认为 `neutral`：继续可玩，但**暂停** Relationship Heat/Signal 的推进；切回 V2 主线玩法后恢复原 Relationship State。
- 后续任何 Pack 想进入 Relationship Engine，必须实现同一 Card Metadata Contract，而不是在 Engine 里写 pack-specific 特例。

## V. 动态路由与离线能力

1. V2 核心玩法不得继续使用“整局预先固定好下一张卡顺序”的旧关系主线逻辑；因为合法候选会随 Heat、Coverage、Pair、Signal、MATCH 改变。
2. 离线能力不下降：350 张主线 + 40 张扩圈本地预载；**每轮在本地候选池动态路由**，无需联网。
3. AI 整局预生成能力可继续服务 neutral pack；它不得绕过 V2 主线的元数据门禁。

## VI. 持久化与敏感状态

允许持久化到 IndexedDB 的 V2 状态：Heat、完成计数、coverage 计数、非原始的聚合 signal、MATCH pair、cooldown、已用 cardId、5档保障进度。

禁止持久化：单向秘密选择原文/对象、未提交的私密动作选择、被拒绝的单边 consent 选项。

Session 结束必须清除 Relationship Graph、MATCH、秘密事件状态；若未来要“保存战绩”，必须作为独立显式 opt-in Change C/B 再设计。

## VII. Brownfield 迁移宪法

1. 当前生产 V1.6 已上线；V2 必须增量迁移，不重做四 Tab、PWA、Provider、IndexedDB 基础设施。
2. 旧 `16:8:4:2:1` / `INTENSITY_WEIGHT` / 固定 4–5档 70% / 全桌H5 / DOUBLE MATCH 等旧路由必须从生产可达路径删除，不能与 V2 双跑。
3. 既有 Active Session 必须事务化迁移；迁移失败不得清空用户数据。
4. 旧 Session 不生成任何“推测型”关系信号。迁移后 Signal/MATCH 初始为空；保留玩家、设置、已完成历史与可安全映射的当前玩法。
5. 若刷新时处于私密选择中，私密事件作废并返回安全主局，不恢复单边答案。
6. PWA/IndexedDB 版本错位保护继续保留；发布时 `package.json` / `public/sw.js` / `public/version.json` 版本联动规则继续有效。

## VIII. 可调参原则

以下均是**可测试默认值**，不是产品真理，禁止散落硬编码：首次互选卡数、互选间隔、最大常规互选次数、Coverage 比例、low-participation 阈值、drawBands、Pair Cooldown、小局降权、MATCH 5档保障窗口。

它们必须由 V1.3 `runtimeRules` 或其受控 schema 承载；真人局内测后可以在不重写引擎的情况下调整。

### 当前 runtimeRules 快照（只为审查展示；实现仍读取 JSON SSOT）

```json
{
  "coverageGate": {
    "mode": "opportunity-based",
    "qualifyingTargetModes": [
      "system-opposite-sex",
      "choose-opposite-sex",
      "system-pair",
      "signal-pair",
      "match-pair"
    ],
    "h3AndMutualCheckRequirement": "each-active-player-offered-at-least-1-qualifying-targeted-opportunity",
    "skipCountsAsOpportunity": true,
    "skipCountsAsCompletedInteraction": false,
    "consecutiveTargetedSkipsBeforeLowParticipation": 2,
    "lowParticipationDoesNotBlockHeatOrMutualCheck": true
  },
  "drawBands": {
    "H1": {
      "1": 1.0
    },
    "H2": {
      "2": 0.8,
      "1": 0.2
    },
    "H3": {
      "3": 0.75,
      "2": 0.25
    },
    "H4": {
      "4": 0.6,
      "3": 0.3,
      "5": 0.1,
      "intensity5OnlyWhenLegal": true,
      "renormalizeUnavailableBuckets": true
    },
    "matchPairDedicated": {
      "5": 0.7,
      "4": 0.3
    }
  },
  "chemistryCompatibility": {
    "intensity1to3": "0.25 per correct directional prediction; max 0.5 per card; pair routing bonus cap +1",
    "card40": "if both revealed preferences match, add 0.5 compatibility evidence",
    "cards41to49": "no compatibility routing effect; MATCH-only experience cards"
  },
  "heatProgression": {
    "fixedRoundProgress": {
      "H1": {
        "minInclusive": 0.0,
        "maxExclusive": 0.2
      },
      "H2": {
        "minInclusive": 0.2,
        "maxExclusive": 0.4
      },
      "H3": {
        "minInclusive": 0.4,
        "maxExclusive": 0.65
      },
      "H4": {
        "minInclusive": 0.65,
        "maxInclusive": 1.0
      }
    },
    "openEndedEffectiveCards": {
      "H1": {
        "min": 0,
        "max": 3
      },
      "H2": {
        "min": 4,
        "max": 7
      },
      "H3": {
        "min": 8,
        "max": 12
      },
      "H4": {
        "min": 13
      }
    },
    "globalHeatMax": "H4"
  },
  "targetedScheduling": {
    "h1h2MinTargetedRatio": 0.4,
    "maxConsecutiveAllPlayerCards": 2
  },
  "mutualCheckScheduler": {
    "firstEligibleEffectiveCardCount": 9,
    "minimumHeat": "H3",
    "minimumEffectiveCardsBetweenRuns": 5,
    "maxRegularRuns": 3,
    "prioritizeAfterNewPersonalSignal": true,
    "finalCheckAtSessionEnd": true
  },
  "intensity5Unlock": {
    "requiresPlayerMaxIntensity": 5,
    "pairSpecificOnly": true,
    "newMatchGuaranteeWithinQualifyingPairOpportunities": 2
  },
  "pairRouting": {
    "formula": "coverageBonus + signalBonus - cooldownPenalty",
    "defaultPairCooldownRounds": 2,
    "coverageBonus": {
      "neverInteracted": 3,
      "lowExposure": 2
    },
    "signalBonus": {
      "sharedPerHit": 0.5,
      "sharedCap": 1.0,
      "compatibilityPerHit": 0.5,
      "compatibilityCap": 1.0,
      "crowdPerHit": 1.0,
      "crowdCap": 2.0,
      "personal": 2.0,
      "personalCap": 2.0,
      "match": 5.0
    },
    "cooldownPenalty": {
      "previousRoundSamePair": 4,
      "samePairTwoConsecutiveRounds": 10
    },
    "smallPool": {
      "maxAvailableOppositeSexPairs": 6,
      "personal": 1.0,
      "personalCap": 1.0,
      "match": 3.0,
      "crowdPerHit": 0.5,
      "crowdCap": 1.0,
      "sharedAndCompatibilityUnchanged": true,
      "matchStillObeysCooldown": true
    }
  },
  "signalFilters": {
    "shared": {
      "positiveResponsesOnly": true,
      "globalPositiveConsensusThreshold": 0.8,
      "bothNegativeDoesNotCount": true
    },
    "eitherCompatibility": {
      "globalConsensusThreshold": 0.8,
      "minimumInformativeCoAnswers": 3,
      "excludeSkippedAnswers": true,
      "privateCardNumbersExcluded": [
        41,
        42,
        50
      ]
    }
  },
  "mostLikely50OneOff": {
    "createsMatch": false,
    "unlocksExactlyOnePairedCard": true,
    "maxIntensity": 4,
    "excludeBoundaryTags": [
      "physical-contact",
      "proximity",
      "photo-video"
    ]
  }
}
```

## IX. 治理与变更

- Authority：Constitution > SPEC > PLAN > TASKS > 临时实现决定。
- 但**数值型 runtime defaults** 的唯一事实源是冻结的 JSON `runtimeRules`；Constitution 只规定不可变语义与边界。
- 若 Constitution 与 runtimeRules 发生语义冲突，视为 Phase 1 阻断，不允许 Builder“选一个看起来合理的”。
- Phase 2 中修改 MATCH 语义、Heat 状态、信号类型、隐私生命周期、SSOT、Session 迁移策略属于 Change C，必须受控重开 PLAN。

## X. Constitution Check（PLAN 必须全部 PASS）

- [ ] 四 Tab / local-first / PWA / Engine-Pack 解耦未破坏。
- [ ] 1–5 开放度 UI 不重做。
- [ ] Session Heat 仅 H1–H4。
- [ ] 5档只按 pair-specific legality 解锁。
- [ ] MATCH 仅由秘密双向选择形成。
- [ ] Skip 不锁死全桌流程。
- [ ] 私密原始答案不持久化。
- [ ] current consent 与 MATCH 分离。
- [ ] runtimeRules 无第二份手写真源。
- [ ] Neutral pack 不污染 Relationship Engine。
- [ ] 旧指数抽法与旧关系逻辑从可达路径删除。
- [ ] 旧 Session 迁移非破坏。
- [ ] FR → Module → Task → Test 可追踪。
- [ ] Phase 1 未启动 Builder/业务代码修改。

**Ratification**：待 Research Reviewer + Human Gate。  
