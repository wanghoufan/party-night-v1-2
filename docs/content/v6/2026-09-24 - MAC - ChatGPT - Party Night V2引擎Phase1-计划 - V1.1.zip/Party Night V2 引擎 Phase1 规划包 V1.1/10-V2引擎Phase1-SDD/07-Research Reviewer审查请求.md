# Party Night V2 Engine Phase 1｜Research Reviewer 审查请求

## 审查对象

- `01-CONSTITUTION-V2引擎.md`
- `02-SPEC-V2引擎.md`
- `03-PLAN-V2引擎.md`
- `04-TASKS-V2引擎.md`
- `05-TRACEABILITY-V2引擎.md`
- V1.3 Frozen `10-卡片元数据.json.runtimeRules`
- 当前仓库 `AGENTS.md` / `docs/handoff/HANDOFF.md`

## Reviewer 必查问题

1. 是否仍存在第二套 runtimeRules / 第二套路由真源？
2. H1–H4、Coverage opportunity、mutual scheduler 是否存在死锁/跳过连带惩罚？
3. dynamic router 与 V1.6 fixed deck 的迁移边界是否清楚，是否可能双路由？
4. Signal 是否存在任何 Crowd/Personal/行为线索错误升级 MATCH 的路径？
5. Multiple MATCH + small pool + cooldown 是否会垄断4–5人小局？
6. “2次pair机会内5档保障”与70/30 dedicated band是否会违反公平/consent？
7. private flow 是否可能在 IndexedDB、log、browser history、analytics 泄露单向选择？
8. 刷新/崩溃/暂离/返回/Session end 是否有隐私残留或状态不可恢复？
9. neutral/expansion不推进Heat这一Phase1决定是否合理？若要改变，是否需要补runtimeRules SSOT字段？
10. V1.6 Active Session transaction migration 是否足够非破坏？
11. 9项 legacy delete 是否完整；是否还有旧 `SEED_INTENSITY_PATTERN` / deck-prefix 假设遗漏？
12. FR→R→Task→Test 是否有断链？
13. 是否保护四Tab、PWA、Provider、PackSwitcher、local-first，不把Change C扩大为重写App？
14. Phase2 Task是否满足 test-first，且MVP Gate只内部检查不暂停？

## 输出要求

Reviewer 请给：

- P0 / blocking P1 / P2 列表；
- 每项证据位置；
- `PLAN_READINESS_SCORE`（0–100）；
- `READY_FOR_HUMAN_REVIEW` 或 `REWORK_REQUIRED`；
- 若整改，只回 Planner，不让用户搬运。

只有 **score ≥90 + P0=0 + blocking P1=0 + 关键事实已验证** 才能进入 Human Gate。
