# Party Night V2 Relationship Engine｜PRODUCT PLAN

> PLAN_VERSION：**PRODUCT_PLAN_V2.0-DRAFT**  
> PROJECT_PHASE：**PLAN**  
> CHANGE_REQUEST：**C｜核心抽卡/Session 关系状态架构升级**  
> DEV_BASELINE：**未建立；Human Gate 前禁止设置**  
> 输入：V1.3 Frozen + 当前生产 V1.6 brownfield 代码  
> 目标状态：`READY_FOR_RESEARCH_REVIEW`

## 1. Summary

这不是“把350张新题替换到现有 seed 数组”这么简单。当前生产 V1.6 仍使用旧的高档陡坡/固定 deck 思路；V2 要新增 Relationship Engine，让下一张合法卡由 Heat、Coverage、Pair、Signal、MATCH、Consent 动态决定。

**增量原则：**保留现有 Next.js/React/TypeScript、四 Tab、Party Game Engine、PackSwitcher、IndexedDB、PWA、AI Provider；只重构 V2 主线卡选择与关系状态层。

## 2. 已核验 brownfield 事实

Phase 1 已读取并确认：

- `AGENTS.md`：Change C 必须走 Planner → Research Reviewer → Human Gate；Phase 1 禁 Builder/业务改动。
- `docs/handoff/HANDOFF.md`：生产 V1.6 已上线；当前种子350张，旧抽法为 `16:8:4:2:1`；四 Tab、local-first、Session v2、PWA 等必须保护。
- `package.json`：Next.js 16.3.3 / React 19 / TypeScript / Zod / idb / Vitest / Playwright。
- `lib/game-packs/built-in-seeds/index.ts`：当前 350 题仍以 TypeScript 硬编码种子 + 固定强度前缀为运行来源，注释明确依赖旧陡坡。

**尚未在 Phase 1 强行猜测的路径**：当前 Session reducer、card selector、IndexedDB repository、PackSwitcher 的实际最终文件路径。Phase 2 的 T001 必须先做 path mapping；PLAN 按模块职责而非臆造文件路径绑定。

## 3. Architecture Decision

### 3.1 SSOT Adapter

新增一个只读 `V2ContentAdapter`：

- 输入唯一为冻结 `10-卡片元数据.json` / `10b-扩圈元数据.json`；
- Zod 校验 schema=2.3、cardId 唯一、runtimeRules 完整；
- RuntimeConfig 从 `runtimeRules` 解析；代码里不得复制一份手写数字常量；
- 若工程不适合直接从 docs import，可使用**生成文件**，但生成物不可手改，并用 hash/test 证明与 SSOT 一致。

### 3.2 Relationship State Slice

在现有 Session 模型内新增 `relationshipState`，而不是创建第二个 Session store。它只维护 Heat、Coverage、pair aggregate state、cooldown、matches、used card ids、5档保障；私密原始答案永不持久化。

### 3.3 Heat / Coverage Engine

纯函数：`nextHeat(state, runtimeRules, sessionProgress)`、`recordOpportunity`、`recordCompletion/skip`。Heat 与 Intensity 分离。

### 3.4 Pair Engine

纯函数计算：`CoverageScore + SignalBonus - CooldownPenalty`。小局权重读取 config；最终 selector 只得到 pair priority，不得到爱情评分。

### 3.5 Signal Engine

只接受 metadata `signalEffects` 的显式事件。各 signal 独立累计和封顶。CHEM 41–49 不再加 Compatibility。

### 3.6 Card Router

把当前“固定 deck/陡坡”职责改造成**动态 eligibility + weighted draw**：

1. capability；2. Intensity；3. Heat；4. target/pair；5. card metadata legality；6. coverage/cooldown；7. drawBands；8. random。

V2 relationship-aware pack 依赖动态 router；neutral pack 可继续原 deck 能力。

### 3.7 Private Flow Engine

不进入持久化 store 的 ephemeral controller，承载 mutual check / one-off mutual / consent intersection。刷新即丢弃 partial answers。

### 3.8 Match Engine

只处理明确 mutual result；维护 non-exclusive pair MATCH 与 5档 guarantee。`SYSTEM_MUTUAL_CHECK` 是 scheduler event，**不得塞进普通 card draw**。

### 3.9 Migration Adapter

事务化把 V1.6 Session 扩展到 V2 relationship state；旧 future deck 不再驱动 relationship-aware 下一张卡。旧 signals 不推断。

## 4. R 条目 + DoD

### R-001｜冻结 SSOT 接入
**Requirement**：V2 runtime 只从 schema 2.3 JSON 读取 cards/runtimeRules。  
**DoD**：启动/测试能验证350+40数量、schema、cardId唯一；手改第二份 runtime 常量会被测试发现。

### R-002｜Session Heat State Machine
**Requirement**：Heat H1–H4 独立于 Intensity。  
**DoD**：所有合法转移有测试；不存在 H5；neutral/expansion 不误推进。

### R-003｜Coverage Gate
**Requirement**：opportunity-based；skip算机会、不算完成。  
**DoD**：1名玩家连续skip不阻塞其他人H3/mutual check；low-participation逻辑可恢复。

### R-004｜Draw Bands
**Requirement**：heatMax硬过滤 + runtime drawBands软权重。  
**DoD**：H3/H4 bucket按SSOT配置；非法5档抽取概率严格为0；无桶时正确归一化。

### R-005｜Pair Engine
**Requirement**：公平优先 + signal bonus + cooldown，小局降权。  
**DoD**：≤6 pair使用小局权重；MATCH不能绕过cooldown；score不暴露给UI。

### R-006｜Signal Separation
**Requirement**：Shared/Compatibility/Crowd/Personal/Mutual分离。  
**DoD**：每类只有允许事件能改变；Crowd/Personal不能创建MATCH；cap测试通过。

### R-007｜SYSTEM_MUTUAL_CHECK
**Requirement**：独立 scheduler，首次/间隔/次数/final由runtimeRules控制。  
**DoD**：不依赖#50；满足条件会due；不满足不触发；final总能触发一次。

### R-008｜Private Choice UX + Privacy
**Requirement**：单设备传手机，单向选择不持久化。  
**DoD**：前一位答案不可回看；刷新丢弃partial；IndexedDB fixture中无unilateral choice。

### R-009｜MATCH + 5档保障
**Requirement**：mutual only；5档pair-specific。  
**DoD**：新MATCH后2次合格pair机会内至少一次5档优先机会；Intensity<5时不解锁；multiple matches可共存。

### R-010｜Consent Intersection
**Requirement**：只执行双方交集；无交集no-action。  
**DoD**：单边拒绝不泄露；无自动替代动作；MATCH不绕过current consent。

### R-011｜MOST-050 One-off Mutual
**Requirement**：群众结果只能创造一次最高4档安全加赛。  
**DoD**：不创建MATCH、不触发5档、不出现physical/proximity/photo卡。

### R-012｜Neutral Pack Compatibility
**Requirement**：AI即兴/转瓶子/自定义包继续可玩但不污染Relationship State。  
**DoD**：切入neutral Heat暂停；切回state原样；现有pack switch不重开Session。

### R-013｜Offline Dynamic Routing
**Requirement**：V2不靠在线AI；本地卡库逐轮动态选卡。  
**DoD**：断网情况下完整跑Heat/match/5档路径；无需预先固定40张关系牌顺序。

### R-014｜V1.6 Migration
**Requirement**：事务化、非破坏。  
**DoD**：players/config/history保留；signals/matches空；legacy current card最多完成一次neutral；失败原数据未删。

### R-015｜Legacy Removal
**Requirement**：删除/断开旧V1.6关系路由。  
**DoD**：以下均无生产可达引用：`INTENSITY_WEIGHT 1/2/4/8/16`、`16:8:4:2:1`、4–5档固定70%、全桌H5、Crowd/Personal→MATCH、无交集自动换动作、private Either长期Compatibility、都没做过→Shared、DOUBLE MATCH、secret unilateral持久化。

### R-016｜Existing Regression
**Requirement**：四Tab/PWA/Provider/IndexedDB/PackSwitch/安全渲染不回退。  
**DoD**：既有 regression + 新V2 regression 全PASS。

### R-017｜Sensitive Session Cleanup
**Requirement**：Session结束删除relation graph/MATCH/private ephemeral。  
**DoD**：结束后重新读取IndexedDB不存在敏感relation state；新局从空开始。

### R-018｜Observability for Tuning
**Requirement**：允许本地、非敏感的调参诊断，不记录谁选谁。  
**DoD**：可输出匿名计数（Heat停留、mutual check触发次数、bucket命中、skip计数），默认不上传，日志不得含player→target秘密边。

## 5. Migration Matrix

| 现有能力 | V2动作 | 说明 |
|---|---|---|
| 四Tab/UI shell | 保留 | 不重做IA |
| Session/IndexedDB | 扩展 | 增 relationshipState + migration |
| Game Pack registry | 保留/扩展capability | relationship-aware / neutral |
| `lib/game-packs/built-in-seeds/index.ts` 旧350 | 从V2主线运行路径替换 | V1.3 JSON成为主线SSOT；旧陡坡注释/前缀不再驱动 |
| 固定40张/整局关系牌顺序 | relationship-aware路径重写 | 改动态router；offline仍在 |
| AI whole-deck | neutral路径保留 | 不驱动V2 signals/match |
| completion/swap/skip | 保留 | 接入V2事件语义 |
| PackSwitcher | 保留 | 切neutral暂停relationship推进 |
| 旧强度陡坡 | 删除 | 被runtime drawBands替代 |
| PWA/Provider/BYOK | 保留 | regression only |

## 6. Runtime Config Strategy

实现不得手写这些值：首次互选=9、间隔=5、常规最多=3、coverage模式、drawBands、小局权重、cooldown、5档保障窗口。Phase 2 adapter读取 `runtimeRules` 并转换成强类型 config。

Research Reviewer / Human Gate 前若发现任何实现所需 runtime 参数只存在于 prose、未进入 JSON SSOT，则 **Phase 1 直接阻断并补齐**；不得把该缺口带入 DEV_BASELINE，更不得由 Builder 从 prose 抄常量到代码。

## 7. Test Strategy

### Unit / property-style fixture

- Heat合法转移与heatMax过滤。
- drawBands归一化、非法bucket=0。
- coverage opportunity/completion/skip差异。
- pair score + cap + small-pool + cooldown。
- signal source whitelist。
- mutual matching、multiple match、unilateral deletion。
- five-card guarantee窗口。
- consent intersection。
- neutral pack pause。
- session end cleanup。

### Integration

- 4人/5人不同比例玩家。
- low-participation不锁死。
- PackSwitcher在relationship-aware/neutral之间切换。
- IndexedDB refresh recovery。
- V1.6 fixture迁移。

### E2E

- H1→H3→SYSTEM_MUTUAL_CHECK→MATCH→5档→final check完整链。
- 无MATCH链：不泄露单向答案、不出现5档。
- refresh during private flow：partial secret消失。
- offline完整主链。
- 四Tab/设置/游戏包/Provider regression。

## 8. Risks / Countermeasures

| 风险 | 级别 | 对策 |
|---|---|---|
| dynamic router与旧fixed deck并存造成双路由 | P0 | legacy removal test + 单一V2入口 |
| 私密答案进入IndexedDB/日志 | P0 | ephemeral controller + persistence denylist test |
| JSON/prose分叉 | P0 | SSOT hash/schema gate |
| 一个skip玩家锁死流程 | P1 | opportunity-based coverage |
| MATCH pair垄断 | P1 | small-pool权重+cooldown+caps |
| AI/custom卡没有metadata却进入V2 | P1 | capability gate=neutral |
| 旧active session迁移失败 | P1 | transaction + fixture + no-delete rollback |
| H4节奏过强/过弱 | P2 | runtimeRules可调，不改引擎 |

## 9. Phase 1 Readiness Gate

进入 Research Review 前必须满足：

- Constitution / SPEC / PLAN / TASKS 四件套完成；
- V1.3 freeze manifest/hash完成；
- runtimeRules SSOT明确；
- migration delete list完整；
- state/event model无明显死锁；
- FR→R→Task→Test可追踪；
- 本轮没有业务代码变更。

**当前 Planner 目标：READY_FOR_RESEARCH_REVIEW，不设置 DEV_BASELINE。**
