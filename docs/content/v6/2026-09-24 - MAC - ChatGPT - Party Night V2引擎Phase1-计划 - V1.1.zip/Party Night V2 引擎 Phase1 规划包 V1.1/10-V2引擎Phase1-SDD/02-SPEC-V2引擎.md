# Party Night V2 Relationship Engine｜SPEC

> 状态：Phase 1 Draft｜待 Research Reviewer  
> 基线：V1.3 Frozen｜schema 2.3  
> 目标：把已经冻结的题库/规则变成**可实现、可测试、可迁移**的关系推进引擎；本文件不授权开发。

## 1. Product Intent

用户仍然在熟悉的 Party Night 四 Tab 和“组局”主局里玩。V2 不增加新的产品入口，而是在同一 Session 内让核心 7 个玩法从“随机抽题”升级为：

**公平破冰 → 共同点/偏好 → 主动选择 → 群体观察 → 系统秘密互选 → MATCH → pair 专属5档 → 当场动作同意 → 结束清理。**

## 2. Actors

- **Host**：拿着唯一一台手机、控制开始/下一题/切玩法/暂停/结束。
- **Player**：参与题目；在私密事件时短暂接过同一台手机。
- **Pair**：两个可参与男女关系推进的玩家组合；不是永久配对。
- **System Event**：不属于普通随机题的系统流程，如 `SYSTEM_MUTUAL_CHECK`、final mutual check、private consent intersection。

## 3. Pack Capability

### 3.1 relationship-aware

V1.3 七类主线。卡片必须有 schema 2.3 metadata；可推进 Heat、Coverage、Signal、Pair Routing、MATCH、5档。

### 3.2 expansion

40 张扩圈卡。使用 `10b-扩圈元数据.json`；不进入 Pair Score/MATCH。默认不推进 Heat / mutual-check interval。

### 3.3 neutral

AI 即兴、转瓶子、自定义 pack 及任何没有 V2 Card Metadata Contract 的 pack。正常可玩、可完成/跳过/切换，但 Relationship Heat 和 Signal 暂停，返回 relationship-aware pack 后继续。

## 4. Functional Requirements

### Session / Heat

- **FR-V2-001**：Session 新建时创建 `relationshipState`，初始 Heat=H1、signals=空、matches=空、cooldowns=空。
- **FR-V2-002**：Intensity 继续使用现有 1–5 UI，仅作为卡片允许上限。
- **FR-V2-003**：Heat 只允许 H1→H2→H3→H4，不存在 H5。
- **FR-V2-004**：relationship-aware 卡完成后按现有总轮数/有效卡规则推进 Heat；neutral / expansion 默认不推进。
- **FR-V2-005**：`heatMin/heatMax` 是硬过滤；drawBands 是合法候选中的软权重。
- **FR-V2-006**：H1/H2 定向机会比例满足 runtimeRules；skip 算 offered opportunity，不算 completed interaction。
- **FR-V2-007**：连续定向 skip 达阈值后标记 `low-participation`；不能阻塞其他玩家升温或互选。

### Card Router

- **FR-V2-008**：每轮顺序固定为：Pack capability → Intensity → Heat → target/pair → metadata legality → Coverage/Cooldown → drawBand → random/select。
- **FR-V2-009**：禁止旧 `16:8:4:2:1` 或固定 4–5档 70% 参与选择。
- **FR-V2-010**：当前 bucket 无合法卡时只能按 runtimeRules 重新归一化/向合法较低档回退，不得越权放更高档。
- **FR-V2-011**：已用卡/换题/跳过的现有去重语义继续保留，但不得破坏 V2 legality。

### Pair / Signals

- **FR-V2-012**：Pair Engine 输出的是下一轮 pair 候选优先级，不输出“喜欢概率”。
- **FR-V2-013**：Coverage / Signal / Cooldown 三部分分别计算后合成 Routing Score。
- **FR-V2-014**：可用异性 pair≤6 时自动应用 runtime small-pool 降权；MATCH pair 仍受 cooldown。
- **FR-V2-015**：Shared / Compatibility / Crowd / Personal / Mutual 分库存储，不互相升级。
- **FR-V2-016**：只有 V1.3 metadata 的 `signalEffects` 可以修改 signal；行为动画/眼神/靠近本身不产生好感 signal。
- **FR-V2-017**：signal cap 必须执行，避免热门 pair 越滚越热门。

### SYSTEM_MUTUAL_CHECK / MATCH

- **FR-V2-018**：首次 mutual check 由 runtimeRules 条件触发，是系统事件，不依赖抽到 #50。
- **FR-V2-019**：Host 启动后，屏幕按玩家逐个进入“交给 X → 准备 → 私密选择 → 提交 → 遮罩”的流程。
- **FR-V2-020**：每位玩家可选一位当前合法异性或“暂时没有”。
- **FR-V2-021**：本轮所有有效选择完成后，仅计算 A→B 且 B→A 的双向边；创建 Session MATCH。
- **FR-V2-022**：单向答案绝不公开；计算后立即从内存删除，不写 IndexedDB。
- **FR-V2-023**：同一玩家允许同时存在多个不同 pair MATCH；MATCH 不排他。
- **FR-V2-024**：常规 mutual check 间隔/次数与 final check 读取 runtimeRules；final check 在 Session 结束前保证一次。
- **FR-V2-025**：刷新/崩溃发生在 mutual check 中时，未完成私密事件作废；恢复主局，不恢复部分答案。

### 5档 / Consent

- **FR-V2-026**：MATCH + Intensity=5 后，该 pair 合法5档进入候选；不得全桌解锁。
- **FR-V2-027**：新 MATCH 的 5档最低出场保障必须跟踪“接下来2次合格双人机会”，在窗口内至少优先出1张合法5档；玩家 skip 不强迫补做同一张。
- **FR-V2-028**：MATCH 专属回合使用 runtime drawBand；5档卡仍需逐卡 consent/target/match legality。
- **FR-V2-029**：`private-mutual-only` 只显示双方选择交集；无交集→no action / continue；不创建 MATCH。
- **FR-V2-030**：具体身体/距离动作在执行前再次 current consent；拒绝不暴露是哪一方。
- **FR-V2-031**：`PN-MOST-050` 只能创建 one-off paired bonus：最高4档、无身体接触/近距离/拍照，不创建 MATCH。

### Session / Persistence / Privacy

- **FR-V2-032**：允许持久化聚合 relationshipState；禁止持久化原始单向私密选择和未提交 consent。
- **FR-V2-033**：暂停/刷新后恢复 Heat、聚合 signals、matches、cooldowns、usedCardIds、5档保障进度。
- **FR-V2-034**：Session end 清空 relationship graph、MATCH、秘密事件临时状态；普通历史/总结按现有产品规则保留。
- **FR-V2-035**：默认不把 Pair Signal/MATCH/秘密答案发到第三方 analytics/AI。

### Brownfield Migration

- **FR-V2-036**：V1.6 Session schema 迁移必须事务化；失败不得清空原记录。
- **FR-V2-037**：迁移保留玩家、关系、氛围、Intensity、active pack、可安全保留的 RoundHistory；V2 signals/MATCH 从空开始，绝不根据旧历史猜测。
- **FR-V2-038**：旧固定 deck 的未来顺序不再作为 V2 relationship-aware 主线；迁移完成后下一次选卡进入 V2 router。
- **FR-V2-039**：若迁移时存在一张已展示的 legacy current card，可允许完成/跳过一次，但它不产 V2 signal；之后切 V2 router。
- **FR-V2-040**：旧生产路径中的指数权重、全桌H5、DOUBLE MATCH、自动替换动作等全部不可达。

### Existing Product Regression

- **FR-V2-041**：四 Tab、主页、组局配置、游戏包、设置、Provider、PWA、offline、PackSwitcher 不因 V2 改版重做。
- **FR-V2-042**：同 Session 切到 neutral pack 时 Relationship State 暂停但不清空；切回继续。
- **FR-V2-043**：本地 350+40 数据在无网环境可完整路由。
- **FR-V2-044**：安全文本渲染、BYOK、Service Worker API exclusion、版本号三处联动规则继续通过原 regression。

## 5. Conceptual Data Model

```text
Session.relationshipState
  heat: H1|H2|H3|H4
  effectiveCardCount
  lastMutualCheckAtCount
  regularMutualCheckRuns
  playerCoverage[playerId]
    offeredTargeted
    completedTargeted
    consecutiveTargetedSkips
    lowParticipation
  pairState[pairKey]
    sharedEvidence
    compatibilityEvidence
    crowdEvidence
    personalEvidence
    matched
    matchedAt
    cooldownRounds
    pendingFiveGuarantee
      eligiblePairOpportunitiesRemaining
      satisfied
  usedCardIds
```

**不进入持久化：** `pendingPrivateAnswers`, `partialConsentSelections`, unilateral secret target。

## 6. State / Event Model

正常 Session 状态与 Heat 分离：

```text
sessionStatus = active | paused | ended
heat = H1 | H2 | H3 | H4
specialFlow = none | mutual-check | one-off-mutual | consent-intersection | final-mutual-check
```

主要事件：

`CARD_COMPLETED` / `CARD_SKIPPED` / `CARD_SWAPPED` / `PACK_SWITCHED` / `HEAT_REEVALUATE` / `SYSTEM_MUTUAL_CHECK_DUE` / `PRIVATE_CHOICE_SUBMITTED` / `MATCH_CREATED` / `MATCH_UPDATED` / `CONSENT_INTERSECTION_DONE` / `PLAYER_TEMP_AWAY` / `PLAYER_RETURNED` / `SESSION_PAUSED` / `SESSION_RESUMED` / `SESSION_END_REQUESTED` / `SESSION_ENDED`。

## 7. Private UI Flow

### Mutual Check

1. Host 看到“现在进行一次私密选择，不公开单向答案”。
2. 屏幕显示“请把手机交给 Alex”。
3. Alex 点“只有我能看到”进入选择页。
4. 选择一位合法异性 / 暂时没有 → 二次确认提交。
5. 提交后立即显示遮罩页“已记录，请交给下一位”，不能返回查看。
6. 全员完成后，系统仅显示新产生的 mutual match；若无新 mutual，显示“选择完成，继续玩”，不说谁没选谁。

### Consent Intersection

双方分别私密勾选可接受动作；系统只显示交集。无交集时显示“这轮不做动作，继续玩”，不揭示单边拒绝。

## 8. Error / Recovery

- metadata/schema 加载失败：relationship-aware pack 不得降级到旧 selector；显示“V2题库校验失败”，允许切 neutral pack/退出，但不能绕过安全规则。
- 私密流程刷新：丢弃 partial answers，恢复到普通 active session；下次按调度器重新触发。
- IndexedDB migration 失败：保留原记录，不写半迁移状态；提示恢复/重试，不清库。
- 当前合法候选为空：按合法较低档/pack capability fallback；不得恢复旧权重算法。

## 9. Non-Goals

- 不做跨手机秘密投票。
- 不做账号/云同步/服务端关系图。
- 不做 ML/AI 猜“谁喜欢谁”。
- 不把 AI 即兴强行迁成 relationship-aware。
- 不重做 UI 视觉系统、四 Tab、Provider。
- Phase 1 不改业务代码。

## 10. Acceptance Scenarios

1. 4人局，一人连续跳过2次定向题：其他玩家仍能在满足计数后进入 mutual check；跳过者可继续被选择。
2. 5人局有新 MATCH：该 pair 在后续2次合格 pair opportunity 内至少获得1次合法5档优先机会；但 cooldown 仍有效。
3. Crowd 多次投同一 pair：只增加封顶 Crowd，永不自动 MATCH。
4. 双方 consent 没共同选项：不执行任何动作，不自动降级成“对视5秒”。
5. mutual check 刷新：之前几个人的单边选择无法恢复、无法泄露。
6. Session 切转瓶子再切回真心话：Heat/Match 不丢，但转瓶子期间不前进 Heat。
7. 离线：350张主线仍能按 Heat/Pair 动态路由。
8. V1.6 active session 升级：玩家/设置/历史保留，signals/matches 为空，不再使用旧陡坡 selector。
