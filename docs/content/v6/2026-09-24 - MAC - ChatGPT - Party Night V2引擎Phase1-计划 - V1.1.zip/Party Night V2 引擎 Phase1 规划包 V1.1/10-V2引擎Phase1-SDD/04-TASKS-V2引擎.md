# Party Night V2 Relationship Engine｜TASKS

> **重要：本文件是 Phase 2 待执行任务，不代表现在可以开发。**  
> 只有 Research Reviewer 通过、Human Gate 通过、用户明确说“第二阶段，开发”后，Task Manager 才能派 Builder。  
> 建议 DEV_BASELINE（批准后）：`PRODUCT_PLAN_V2.0`

## Phase 0｜Pre-Implementation Analyze（必须先做）

- [ ] **V2-T001** 读取 AGENTS / role card / override / HANDOFF / 经验，记录 git status/branch；对当前真实仓库建立 path mapping：Session model/reducer、card selector/deck、registry、PackSwitcher、repositories/IndexedDB、PWA/version、tests。**只记录，不搬目录。**
- [ ] **V2-T002** 跑当前 baseline：lint / typecheck / unit / integration / E2E / build；记录历史失败，禁止把旧失败算V2回归。
- [ ] **V2-T003** 执行 pre-implementation Analyze（Spec Kit可用则 `/speckit.analyze`；否则等价人工矩阵），对 Constitution/SPEC/PLAN/TASKS 做冲突检查。CRITICAL/HIGH 先回 Phase1。
- [ ] **V2-T004** 建立 V1.6 Active Session / 空局 / 4人 / 5人 / unequal gender / neutral pack fixture；测试先行。

**Gate A：** path mapping + baseline + Analyze 全PASS 才能开始实现。

## Phase 1｜SSOT / Schema Adapter

- [ ] **V2-T005** 为 `10-卡片元数据.json` / `10b-扩圈元数据.json` 建 Zod/现有schema adapter；验证 schema2.3、数量、唯一ID、runtimeRules。
- [ ] **V2-T006** 写 SSOT divergence tests：禁止手写第二份 drawBands/coverage/chemistry runtime defaults；若使用生成文件，验证生成hash与源一致。
- [ ] **V2-T007** 定义 Pack capability：`relationship-aware | expansion | neutral`；现有 AI 即兴/转瓶子/自定义默认 neutral。
- [ ] **V2-T008** 将七类主线 V1.3 卡映射到现有 GameCard contract；保持现有 pack id / registry compatibility，避免 Session 引用断裂。

## Phase 2｜Relationship State / Persistence

- [ ] **V2-T009** 扩展 Session schema：heat、coverage、pair aggregate、matches、cooldown、usedCardIds、fiveGuarantee。
- [ ] **V2-T010** 明确 persistence allowlist/denylist；单向秘密选择、partial consent 不得进 IndexedDB。
- [ ] **V2-T011** 写 Session serialize/restore tests：正常 relationship state 可恢复，private ephemeral 不可恢复。
- [ ] **V2-T012** 实现 Session end cleanup；写“结束后敏感relation state为空”的测试。

## Phase 3｜Heat / Coverage / Draw Router

- [ ] **V2-T013** Test-first：Heat H1–H4 transition + intensity ceiling + heatMin/heatMax hard filter。
- [ ] **V2-T014** 实现 Coverage opportunity/completed/skip/low-participation；测试一人连续skip不锁死。
- [ ] **V2-T015** 实现 H1/H2 targeted scheduling约束（≥40%、最多连续2张全桌题），参数来自SSOT。
- [ ] **V2-T016** 实现 drawBands weighted selection + unavailable bucket renormalization。
- [ ] **V2-T017** 移除 relationship-aware 路径的旧 `16:8:4:2:1` / fixed high-intensity slope / 4–5档70%逻辑与相关断言。
- [ ] **V2-T018** 保留 swap/skip/recent dedupe，但放在 V2 legality 之后；测试不得用去重绕过合法性。

**Gate B：** 不依赖UI，测试可以证明 Heat/Coverage/Router 从 H1 到 H4 正确。

## Phase 4｜Pair / Signal Engine

- [ ] **V2-T019** 实现稳定 pairKey 与 active eligible pair pool；处理暂离/返回/性别数量不均。
- [ ] **V2-T020** 实现 CoverageScore / SignalBonus / CooldownPenalty 三段式路由。
- [ ] **V2-T021** 实现 small-pool 权重（≤6 pairs）与各 signal cap；MATCH不得绕cooldown。
- [ ] **V2-T022** 实现 Shared 口径：仅共同“做过”、≥80%排除、“都没做过”不计。
- [ ] **V2-T023** 实现 Either Compatibility 口径：公开有效共同答案、≥3题、共识题排除、私密41/42/50不计。
- [ ] **V2-T024** 实现 Chemistry Compatibility：1–3档预测证据、#40偏好一致；41–49无routing effect。
- [ ] **V2-T025** 实现 Crowd/Personal source whitelist；Crowd只允许MOST 4档pair vote。

## Phase 5｜Private Flow / MATCH / 5档

- [ ] **V2-T026** 实现 ephemeral PrivateFlow controller；未提交/单向答案只在内存存在。
- [ ] **V2-T027** 实现 pass-the-phone Mutual Check UI：交给玩家→准备→选择→确认→遮罩→下一位。
- [ ] **V2-T028** 实现 `SYSTEM_MUTUAL_CHECK` scheduler：首次/间隔/最多次数/final来自SSOT，不并入普通抽卡。
- [ ] **V2-T029** 实现 mutual graph match：仅 A↔B 形成；multiple matches允许；单向结果计算后清除。
- [ ] **V2-T030** 实现刷新/崩溃恢复：private flow取消，回安全主局，不恢复partial答案。
- [ ] **V2-T031** 实现 MATCH pair 5档候选资格 + dedicated drawBand。
- [ ] **V2-T032** 实现“2次合格pair机会内至少优先1张合法5档”的 guarantee tracker；测试 cooldown/skip/intensity<5。
- [ ] **V2-T033** 实现 private-mutual consent intersection；无交集 no-action；不泄露单边选择。
- [ ] **V2-T034** 实现 `PN-MOST-050` one-off bonus（≤4档、安全双人卡、不MATCH）。

**Gate C：** 测试可完整跑 `H3 → mutual check → MATCH → 5档` 和 `无MATCH` 两条链。

## Phase 6｜Pack Integration / Neutral / Expansion

- [ ] **V2-T035** relationship-aware pack 接 V2 router；neutral pack 继续现有玩法路径但暂停relationship推进。
- [ ] **V2-T036** PackSwitcher切 neutral/relationship-aware 时 Relationship State 不丢、不重复初始化。
- [ ] **V2-T037** 扩圈40卡接10b metadata；不进Heat/PairScore/MATCH；拒绝走table fallback。
- [ ] **V2-T038** Offline test：断网下350+40本地内容仍能动态routing、match、5档。

## Phase 7｜V1.6 Migration

- [ ] **V2-T039** 写 V1.6→V2 migration tests（先失败）：players/config/intensity/active pack/history保留，signals/matches为空。
- [ ] **V2-T040** 实现事务化 migration；旧future deck不再驱动relationship-aware下一张。
- [ ] **V2-T041** 若升级时存在legacy current card，允许一次完成/跳过neutral处理；之后进入V2 router。
- [ ] **V2-T042** migration失败保留原记录，不清库、不写半迁移schema。
- [ ] **V2-T043** Legacy removal grep/test：9项旧规则在生产可达代码中为0；旧历史文档可保留。

## Phase 8｜UI / Regression / QA

- [ ] **V2-T044** 主局卡面接入target/pair显示，但不把Routing Score/秘密单向选择暴露给UI。
- [ ] **V2-T045** Mutual/MATCH结果文案：只公布共同结果；无match显示中性完成态。
- [ ] **V2-T046** Consent UI明确“当次动作、可跳过、可随时停止”；不把MATCH当授权。
- [ ] **V2-T047** 四Tab、首页、组局设置、游戏包、设置、Provider regression。
- [ ] **V2-T048** PWA/offline/refresh/IndexedDB recovery regression。
- [ ] **V2-T049** Security/privacy test：logs/export/cache/analytics无单向秘密选择。
- [ ] **V2-T050** 4人/5人/unequal gender/low participation/multiple match E2E矩阵。
- [ ] **V2-T051** production-like build/start + Playwright smoke；版本号联动规则校验。

## Phase 9｜Converge / Release Readiness（仍属Phase2开发闭环）

- [ ] **V2-T052** Converge：逐项核对 FR/R/Task/Test，无P0、blocking P1。
- [ ] **V2-T053** Code Reviewer / QA / Supervisor 全链通过；按ORCA任务账本记录。
- [ ] **V2-T054** 真机酒吧/弱光流程验收：至少4人局+5人局各1轮，重点看私密传手机、节奏、尴尬暴露、5档时机。
- [ ] **V2-T055** 仅在用户最终放行后按项目规则 commit/push/手动生产部署，并同步生产地址。

## DoD 汇总

- 350+40 SSOT 驱动，schema2.3；无第二套 runtime constants。
- 旧陡坡与9项legacy关系逻辑不可达。
- H1→H4 / Pair / Signal / Mutual / MATCH / 5档 / Consent 完整测试。
- 单向私密数据不持久化、不日志、不上传。
- Neutral pack/四Tab/PWA/Provider/PackSwitcher无回归。
- V1.6 Session迁移非破坏。
- lint/typecheck/unit/integration/e2e/build全PASS。
- Human Gate/V1 Gate前不Release。
