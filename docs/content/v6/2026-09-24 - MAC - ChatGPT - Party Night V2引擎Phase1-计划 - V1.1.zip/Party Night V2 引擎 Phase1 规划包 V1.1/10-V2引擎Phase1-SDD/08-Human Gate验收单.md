# Party Night V2 Engine Phase 1｜Human Gate 验收单

> 当前状态：**等待 Research Reviewer，尚未进入 Human Gate。**

Research Reviewer 达到 Readiness Gate 后，用户只需要审以下产品级问题，不需要审代码细节：

1. 是否同意 V2 核心7玩法从“固定预排关系牌”改为“本地动态 Heat/Pair/Card Router”？
2. 是否同意秘密互选作为单设备传手机的受控例外？
3. 是否同意 AI即兴/转瓶子/自定义包默认 neutral，不参与 Heat/Signal/MATCH？
4. 是否同意 Expansion 不推进 Relationship Heat / mutual interval？
5. 是否同意同一玩家可同时存在多个 Session MATCH，而不是锁定唯一对象？
6. 是否同意 V1.6 active session 迁移后 Signals/MATCH 从空开始，不根据旧历史猜测？
7. 是否同意删除旧 16:8:4:2:1 等全部 legacy relationship routing？
8. 是否同意 runtimeRules 是后续真人测试可调参数，而不是硬编码产品真理？

### Human Gate 决策

- [ ] `APPROVED` → 用户明确说 **“第二阶段，开发”**，建立 `DEV_BASELINE=PRODUCT_PLAN_V2.0`。
- [ ] `REVISE` → 回 Planner，仍处于 PLAN。
- [ ] `HOLD` → 保持 V1.6 生产，不开发 V2。

**任何情况下不得自动跨越此 Gate。**
