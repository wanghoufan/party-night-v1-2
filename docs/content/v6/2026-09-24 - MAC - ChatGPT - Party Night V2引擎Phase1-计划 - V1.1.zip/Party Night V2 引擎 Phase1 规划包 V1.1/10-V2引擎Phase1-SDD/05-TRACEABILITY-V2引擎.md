# Party Night V2 Relationship Engine｜Traceability Matrix

| SPEC FR | PLAN R | 主要模块 | Phase2 Tasks | 核心验证 |
|---|---|---|---|---|
| FR-V2-001–007 | R-002,R-003 | Session/Heat/Coverage | T009,T013–T015 | Heat + skip/coverage fixtures |
| FR-V2-008–011 | R-004 | Card Router | T016–T018 | legality + drawBands + dedupe |
| FR-V2-012–017 | R-005,R-006 | Pair/Signal | T019–T025 | caps/small-pool/source whitelist |
| FR-V2-018–025 | R-007,R-008 | Scheduler/Private Flow | T026–T030 | trigger/privacy/refresh |
| FR-V2-026–031 | R-009,R-010,R-011 | Match/5档/Consent | T031–T034 | guarantee/intersection/MOST050 |
| FR-V2-032–035 | R-017 | Persistence/Privacy | T010–T012,T049 | IndexedDB/log denylist |
| FR-V2-036–040 | R-014,R-015 | Migration/Legacy removal | T039–T043 | V1.6 fixtures + grep/test |
| FR-V2-041–044 | R-012,R-013,R-016 | Existing integration | T035–T038,T044–T051 | pack switch/offline/regression |

## 关键不可漏映射

- `runtimeRules.coverageGate` → R-003 → T014/T015。
- `runtimeRules.drawBands` → R-004 → T016。
- `SYSTEM_MUTUAL_CHECK` → R-007 → T028。
- “2次机会内5档保障” → R-009 → T032。
- small-pool降权 → R-005 → T021。
- CHEM compatibility收敛 → R-006 → T024。
- 9项 migration delete → R-015 → T017/T043。
- secret raw answers lifecycle → R-008/R-017 → T026/T030/T049。
