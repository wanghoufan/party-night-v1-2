# Party Night V2 Engine Phase 1｜Planner 交叉检查报告

> 这不是 Research Reviewer 的独立结论；只是 Planner 自检证据。

## 1. 已主动解决的历史冲突

1. **V1.6 fixed deck vs V2 dynamic routing**：核心7玩法改动态本地router；离线能力保留；neutral pack可继续旧deck能力。
2. **“不逐人手机录入” vs 秘密互选**：只为 mutual check / private consent 开两个受控例外，普通题仍Host驱动。
3. **Intensity 5 vs Heat 5**：Heat无H5；5是pair legality。
4. **全桌起哄 vs MATCH**：Crowd仅signal；MOST-050只one-off安全加赛。
5. **Skip vs Coverage Gate**：机会门槛与完成次数拆开，skip不锁死别人。
6. **持久化恢复 vs 私密原始答案**：聚合state可恢复，partial private flow刷新即丢。
7. **AI/custom pack vs V2 metadata**：缺metadata即neutral，不污染Relationship Engine。
8. **SSOT vs prose**：runtimeRules只读JSON，00为人读镜像。
9. **旧active session vs删除旧router**：事务迁移后由V2接管；不保留双引擎生产路径。

## 2. State-machine 死锁检查

- H3 Gate：opportunity-based，不因持续skip锁死。
- Mutual check：有最大常规次数且final独立兜底，不无限循环。
- 无MATCH：回普通session，不等待MATCH。
- 有MATCH但Intensity<5：继续H3/H4普通内容，不等待5档。
- 5档无合法卡：renormalize到合法4档，不死锁。
- private flow刷新：cancel→active，不恢复半状态。
- player temp-away：从eligible target pool移除；返回后可重新进入，不删除已有聚合pair状态。
- multiple matches：非排他，靠pair cooldown/small-pool控制，不需要“选唯一伴侣”。

## 3. Brownfield 保护检查

PASS：四Tab、PWA、IndexedDB、Provider、PackSwitcher、local-first、1–5 UI、同Session切玩法均保留。  
PASS：未要求新状态框架/云库/多设备。  
PASS：Phase1未改GitHub业务代码、未commit、未push、未部署。

## 4. Known Assumptions（Research Reviewer 必须挑战）

- Expansion / neutral 默认不推进 Relationship Heat / mutual interval：这是 Phase1 新架构决定，不改冻结题库；Reviewer 应重点判断该 capability 语义是否合理。
- Neutral pack 暂停Relationship progression：同上，是为了防无metadata内容污染关系逻辑的保守策略。
- V1.6 active session允许“当前已展示legacy card完成一次再切V2”：需Phase2 path mapping确认现有Session结构可安全表达。
- 当前准确的Session/router/repository文件路径需T001核验；Phase1没有臆造路径。

## 5. Planner Readiness Self-Score

- Scope/目标：10/10
- SSOT/数据契约：10/10
- State machine：19/20
- Privacy/consent：20/20
- Brownfield migration：18/20
- Traceability/testability：18/20

**Planner self-score：95/100。**  
P0：0（Planner视角）  
Blocking P1：0（Planner视角）  
状态：**READY_FOR_RESEARCH_REVIEW**  
注意：该分数不能替代 Research Reviewer 独立打分，也不能跨 Human Gate。
